# Third-party notices

## SoundGen Quick implementation adaptation

`app/src/main/java/ai/ady/companion/SoundGenQuickBackend.kt` adapts the Quick inference path and its SentencePiece protobuf tokenizer from `android/app/src/main/java/com/llmhub/llmhub/data/MusicGeneratorBackend.kt` in [timmyy123/LLM-Hub](https://github.com/timmyy123/LLM-Hub). The upstream repository's LICENSE (copyright (c) 2026 timmy) is PolyForm Noncommercial License 1.0.0. It permits copying, modification, and distribution only for noncommercial purposes; commercial uses (including app-store/platform distribution, fees, ads, subscriptions, sponsorships, or revenue-generating products/services) require a separate written license from timmy@llm-hub.app. The license text and attribution must accompany copies or substantial portions. This app must not be commercially distributed with this adapted code unless separately licensed.

The downloaded SoundGen model files are not covered by the source-code license above. Check the model repository and upstream model licenses/terms before redistribution or any use not permitted by their licensors. This app downloads those model files directly to private app storage and does not bundle them in the APK.

The LiteRT runtime is an external Google Maven dependency (`com.google.ai.edge.litert:litert` and `litert-gpu`, version 2.3.0), governed by its respective licenses.

Full upstream LICENSE text (as required for substantial portions):

```text
PolyForm Noncommercial License 1.0.0

Copyright (c) 2026 timmy (timmy@llm-hub.app)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to use,
copy, modify, and distribute the Software for noncommercial purposes only,
subject to the following conditions:

1. NONCOMMERCIAL USE ONLY. You may not use the Software, or any derivative
   work based on it, for any Commercial Purpose. "Commercial Purpose" means:
   (a) distributing or making available the Software or a derivative work
       on any app store or platform (including but not limited to Google Play,
       Amazon Appstore, Samsung Galaxy Store, or any third-party app store);
   (b) charging any fee for the Software or access to it;
   (c) monetizing the Software through advertising, in-app purchases,
       subscriptions, sponsorships, or any other revenue-generating mechanism;
   (d) using the Software in any product or service that generates revenue.

2. ATTRIBUTION. The above copyright notice and this permission notice shall be
   included in all copies or substantial portions of the Software.

3. NO SUBLICENSING FOR COMMERCIAL USE. You may not sublicense the Software or
   any derivative work to any third party for Commercial Purposes.

4. COMMERCIAL LICENSING. If you wish to use the Software for a Commercial
   Purpose, you must obtain a separate written license from the copyright
   holder. Contact: timmy@llm-hub.app

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

The upstream LLM-Hub source adaptation was fetched from `https://raw.githubusercontent.com/timmyy123/LLM-Hub/main/android/app/src/main/java/com/llmhub/llmhub/data/MusicGeneratorBackend.kt` on 2026-11-08. The adapted implementation deliberately contains only SoundGen Quick, the required tokenizer, WAV writer, and LiteRT stage helpers; no HD or unrelated application code was copied.
