package ai.ady.musicstudio

import android.content.Context
import android.util.Log
import com.google.ai.edge.litert.Accelerator
import com.google.ai.edge.litert.CompiledModel
import com.google.ai.edge.litert.TensorBuffer
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.Normalizer
import java.util.Random
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * SoundGen Quick (three-stage LiteRT pipeline), adapted from MusicGeneratorBackend.kt
 * in timmyy123/LLM-Hub. Source adaptation is under PolyForm Noncommercial License 1.0.0;
 * see THIRD_PARTY_NOTICES.md. Model weights are separately licensed by their publishers.
 *
 * All models are compiled and released one stage at a time to limit peak native memory.
 */
object SoundGenQuickBackend {
    private const val TAG = "SoundGenQuick"
    private const val SAMPLE_RATE = 44_100
    private const val CHANNELS = 2
    private const val CHANNEL_SAMPLES = 524_288
    private val lock = Any()

    @JvmStatic fun modelsReady(context: Context): Boolean {
        val dir = File(context.filesDir, "models")
        return listOf("soundgen-conditioners.tflite", "soundgen-dit.tflite", "soundgen-autoencoder.tflite", "soundgen-spiece.model")
            .all { File(dir, it).let { f -> f.isFile && f.length() > 0 } }
    }

    /** Generate a WAV file from prompt. Call from a worker thread, never the UI thread. */
    @JvmStatic fun generate(context: Context, prompt: String, durationSeconds: Float, qualitySteps: Int, progress: Progress): File = synchronized(lock) {
        require(prompt.isNotBlank()) { "Describe the sound or music first." }
        require(durationSeconds in 1f..11f) { "SoundGen Quick supports 1–11 seconds." }; require(qualitySteps in 4..8) { "Quality must use 4–8 diffusion steps." }
        val modelDir = File(context.filesDir, "models")
        val textFile = required(modelDir, "soundgen-conditioners.tflite")
        val coreFile = required(modelDir, "soundgen-dit.tflite")
        val decodeFile = required(modelDir, "soundgen-autoencoder.tflite")
        val tokenizer = Tokenizer.load(required(modelDir, "soundgen-spiece.model"))
        val seed = System.nanoTime()
        progress.onProgress(0.02f, "Preparando descripción")
        val ids = LongArray(128)
        val mask = LongArray(128)
        tokenizer.encode(prompt).take(128).forEachIndexed { i, id -> ids[i] = id.toLong(); mask[i] = 1L }

        progress.onProgress(0.04f, "Interpretando la descripción")
        val pair = createModel(textFile, "Quick conditioner").useModel { model ->
            model.buffers { inputs, outputs ->
                inputs[0].writeLong(ids); inputs[1].writeLong(mask); inputs[2].writeFloat(floatArrayOf(durationSeconds))
                model.run(inputs, outputs)
                outputs[0].readFloat() to outputs[2].readFloat()
            }
        }
        System.gc()
        progress.onProgress(0.12f, "Preparando la generación de audio")

        val conditioning = pair.first
        val conditioningMask = pair.second
        val schedule = FloatArray(qualitySteps + 1) { i -> when (i) { 0 -> 1f; qualitySteps -> 0f; else -> 1f / (exp((-6.0 + 12.0 * i / qualitySteps).toFloat().toDouble()).toFloat() + 1f) } }
        val latent = gaussian(seed, 16_384)
        val next = FloatArray(16_384)
        val noise = FloatArray(16_384)
        val time = FloatArray(1)
        createModel(coreFile, "Quick DiT").useModel { model ->
            model.buffers { inputs, outputs ->
                inputs[0].writeFloat(conditioning); inputs[1].writeFloat(conditioningMask)
                repeat(qualitySteps) { step ->
                    inputs[2].writeFloat(latent); time[0] = schedule[step]; inputs[3].writeFloat(time)
                    model.run(inputs, outputs)
                    val velocity = outputs[0].readFloat()
                    fillGaussian(seed + step + 4564L, noise)
                    for (i in latent.indices) next[i] = noise[i] * schedule[step + 1] + (1f - schedule[step + 1]) * (latent[i] - velocity[i] * time[0])
                    System.arraycopy(next, 0, latent, 0, latent.size)
                    progress.onProgress(0.12f + ((step + 1) * 0.78f / qualitySteps), "Generando audio · paso ${step + 1}/$qualitySteps")
                }
            }
        }
        System.gc()
        progress.onProgress(0.92f, "Construyendo el sonido")
        val audio = createModel(decodeFile, "Quick decoder", true).useModel { model ->
            model.buffers { inputs, outputs -> inputs[0].writeFloat(latent); model.run(inputs, outputs); outputs[0].readFloat() }
        }
        System.gc()
        progress.onProgress(0.96f, "Guardando WAV")
        val frames = min(CHANNEL_SAMPLES, max(1, (durationSeconds * SAMPLE_RATE).roundToInt()))
        val outDir = File(context.filesDir, "audio").apply { mkdirs() }
        val output = File(outDir, "soundgen_${System.currentTimeMillis()}.wav")
        writeWav(output, audio, CHANNEL_SAMPLES, frames)
        progress.onProgress(1f, "Audio generado")
        output
    }

    @JvmStatic fun unload() { synchronized(lock) { System.gc() } }
    interface Progress { fun onProgress(value: Float, message: String) }

    private fun required(dir: File, name: String): File = File(dir, name).also { require(it.isFile && it.length() > 0) { "Missing model file $name. Download all SoundGen Quick model files first." } }
    private fun createModel(file: File, stage: String, texture: Boolean = false): CompiledModel = try {
        val options = CompiledModel.Options(Accelerator.GPU, Accelerator.CPU)
        if (texture) options.gpuOptions = CompiledModel.GpuOptions(bufferStorageType = CompiledModel.GpuOptions.BufferStorageType.TEXTURE_2D)
        Log.i(TAG, "Compiling $stage with GPU/CPU fallback")
        CompiledModel.create(file.absolutePath, options)
    } catch (t: Throwable) {
        Log.w(TAG, "$stage GPU compile failed; falling back to CPU", t)
        CompiledModel.create(file.absolutePath, CompiledModel.Options(Accelerator.CPU))
    }
    private inline fun <T> CompiledModel.useModel(block: (CompiledModel) -> T): T = try { block(this) } finally { runCatching { close() } }
    private inline fun <T> CompiledModel.buffers(block: (List<TensorBuffer>, List<TensorBuffer>) -> T): T {
        val input = createInputBuffers(); val output = createOutputBuffers()
        return try { block(input, output) } finally { input.forEach { runCatching { it.close() } }; output.forEach { runCatching { it.close() } } }
    }
    private fun gaussian(seed: Long, size: Int) = FloatArray(size).also { fillGaussian(seed, it) }
    private fun fillGaussian(seed: Long, a: FloatArray) { val r = Random(seed); for (i in a.indices) a[i] = r.nextGaussian().toFloat() }

    private fun writeWav(file: File, audio: FloatArray, rightOffset: Int, frames: Int) {
        require(audio.size >= rightOffset + frames) { "Decoder returned ${audio.size} samples; expected ${rightOffset + frames}." }
        val bytes = frames * CHANNELS * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII)); putInt(36 + bytes); put("WAVE".toByteArray(Charsets.US_ASCII)); put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16); putShort(1); putShort(CHANNELS.toShort()); putInt(SAMPLE_RATE); putInt(SAMPLE_RATE * CHANNELS * 2); putShort((CHANNELS * 2).toShort()); putShort(16); put("data".toByteArray(Charsets.US_ASCII)); putInt(bytes)
        }.array()
        BufferedOutputStream(FileOutputStream(file)).use { out ->
            out.write(header)
            val batch = ByteBuffer.allocate(4096 * CHANNELS * 2).order(ByteOrder.LITTLE_ENDIAN)
            var frame = 0
            while (frame < frames) {
                batch.clear(); val count = min(4096, frames - frame)
                for (j in 0 until count) {
                    val i = frame + j
                    batch.putShort((audio[i].coerceIn(-1f, 1f) * 32767f).roundToInt().toShort())
                    batch.putShort((audio[rightOffset + i].coerceIn(-1f, 1f) * 32767f).roundToInt().toShort())
                }
                out.write(batch.array(), 0, count * CHANNELS * 2); frame += count
            }
        }
    }

    private data class Piece(val text: String, val score: Float, val type: Int)
    private class Tokenizer(private val pieces: Map<String, Int>, private val scores: FloatArray, private val maxLength: Int, private val fallback: Float) {
        fun encode(value: String): IntArray {
            val normalized = Normalizer.normalize(value, Normalizer.Form.NFKC).trim().replace(Regex("\\s+"), " ")
            val text = "▁" + normalized.replace(' ', '▁')
            if (text.isEmpty()) return intArrayOf(1)
            val best = FloatArray(text.length + 1) { Float.NEGATIVE_INFINITY }; best[0] = 0f
            val previous = IntArray(text.length + 1) { -1 }; val token = IntArray(text.length + 1) { 2 }
            for (start in text.indices) {
                if (best[start] == Float.NEGATIVE_INFINITY) continue
                for (length in 1..min(maxLength, text.length - start)) {
                    val id = pieces[text.substring(start, start + length)] ?: continue
                    val candidate = best[start] + scores[id]
                    if (candidate > best[start + length]) { best[start + length] = candidate; previous[start + length] = start; token[start + length] = id }
                }
                if (best[start] + fallback > best[start + 1]) { best[start + 1] = best[start] + fallback; previous[start + 1] = start; token[start + 1] = 2 }
            }
            val result = ArrayList<Int>(); var cursor = text.length
            while (cursor > 0) { result.add(token[cursor]); cursor = previous[cursor] }
            result.reverse(); if (result.lastOrNull() != 1) result.add(1)
            return result.toIntArray()
        }
        companion object {
            fun load(file: File): Tokenizer {
                val parsed = parseSentencePiece(file.readBytes()); val scores = FloatArray(parsed.size) { Float.NEGATIVE_INFINITY }; val map = HashMap<String, Int>(parsed.size * 2); var max = 1; var minimum = 0f
                parsed.forEachIndexed { index, p -> scores[index] = p.score; if ((p.type == 1 || p.type == 4) && p.text.isNotEmpty()) { map[p.text] = index; max = maxOf(max, p.text.length); minimum = minOf(minimum, p.score) } }
                return Tokenizer(map, scores, max, minimum - 10f)
            }
        }
    }
    private fun parseSentencePiece(bytes: ByteArray): List<Piece> {
        val r = ProtoReader(bytes); val result = ArrayList<Piece>()
        while (!r.done) {
            val tag = r.varint().toInt()
            if (tag ushr 3 == 1 && tag and 7 == 2) {
                val length = r.varint().toInt(); val end = r.position + length; require(length >= 0 && end in r.position..bytes.size) { "Malformed SentencePiece entry" }
                var text = ""; var score = 0f; var type = 1
                while (r.position < end) { val t = r.varint().toInt(); when { t ushr 3 == 1 && t and 7 == 2 -> text = r.string(); t ushr 3 == 2 && t and 7 == 5 -> score = r.float32(); t ushr 3 == 3 && t and 7 == 0 -> type = r.varint().toInt(); else -> r.skip(t and 7) } }
                r.position = end; result.add(Piece(text, score, type))
            } else r.skip(tag and 7)
        }
        require(result.isNotEmpty()) { "Invalid SentencePiece model" }; return result
    }
    private class ProtoReader(private val data: ByteArray) {
        var position = 0; val done get() = position >= data.size
        fun varint(): Long { var result = 0L; var shift = 0; while (shift < 64) { require(position < data.size) { "Truncated protobuf" }; val b = data[position++].toInt() and 255; result = result or ((b and 127).toLong() shl shift); if (b and 128 == 0) return result; shift += 7 }; error("Bad protobuf varint") }
        fun string(): String { val n = varint().toInt(); require(n >= 0 && position + n in position..data.size); return data.decodeToString(position, position + n).also { position += n } }
        fun float32(): Float { require(position + 4 <= data.size); val v = ByteBuffer.wrap(data, position, 4).order(ByteOrder.LITTLE_ENDIAN).float; position += 4; return v }
        fun skip(wire: Int) { when (wire) { 0 -> varint(); 1 -> advance(8); 2 -> advance(varint().toInt()); 5 -> advance(4); else -> error("Unsupported protobuf wire type $wire") } }
        private fun advance(n: Int) { require(n >= 0 && position + n in position..data.size); position += n }
    }
}
