package ai.ady.musicstudio

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.Executors

/** Resumable, size- and SHA-256-verified downloads for the four SoundGen Quick assets. */
object AudioModelCatalog {
    data class Item(val title:String,val url:String,val file:String,val bytes:Long,val sha:String)
    val items = listOf(
        Item("Decodificador", "https://huggingface.co/jegly/audio/resolve/e50bf9dff759c8622371a9c43ede989ea2d04b32/autoencoder_model.tflite?download=true", "soundgen-autoencoder.tflite",312588244,"e5483ee50915af1ac419fce5206f14b55572176fcb9cf327ef48432d4c5feba2"),
        Item("Condicionador de texto", "https://huggingface.co/jegly/audio/resolve/e50bf9dff759c8622371a9c43ede989ea2d04b32/conditioners_float32.tflite?download=true", "soundgen-conditioners.tflite",440190572,"c1139b09ea66a944966dfce4722075401f9eb723c1f59bfd5bdd797690bcce91"),
        Item("Modelo generador DiT", "https://huggingface.co/jegly/audio/resolve/e50bf9dff759c8622371a9c43ede989ea2d04b32/dit_model.tflite?download=true", "soundgen-dit.tflite",344293232,"119fe0020f2fafd88366a2869fdbf2f1aaa3933f8daf64d2116dcc115348ee83"),
        Item("Tokenizador", "https://huggingface.co/jegly/audio/resolve/e50bf9dff759c8622371a9c43ede989ea2d04b32/spiece.model?download=true", "soundgen-spiece.model",791656,"d60acb128cf7b7f2536e8f38a5b18a05535c9e14c7a355904270e15b0945ea86")
    )
    interface Listener { fun progress(index:Int, item:String, downloaded:Long, total:Long); fun complete(); fun error(message:String) }
    private val io=Executors.newSingleThreadExecutor(); private val main=Handler(Looper.getMainLooper())
    private fun dir(c:Context)=File(c.filesDir,"models").apply{mkdirs()}
    fun ready(c:Context)=items.all { val f=File(dir(c),it.file); f.isFile&&f.length()==it.bytes }
    fun downloadAll(c:Context,listener:Listener) { val app=c.applicationContext; io.execute {
        try { items.forEachIndexed { index,item -> downloadOne(app,item,index,listener) }; main.post{listener.complete()} }
        catch(t:Throwable){ main.post{listener.error(t.message?:t.javaClass.simpleName)} }
    } }
    private fun downloadOne(c:Context,item:Item,index:Int,l:Listener) {
        val folder=dir(c); val dest=File(folder,item.file); if(dest.isFile&&dest.length()==item.bytes&&digest(dest)==item.sha)return
        if(dest.exists())dest.delete()
        val part=File(folder,item.file+".part"); var offset=if(part.exists())part.length() else 0L
        if(offset>item.bytes){part.delete();offset=0}
        val conn=URL(item.url).openConnection() as HttpURLConnection
        conn.connectTimeout=30000;conn.readTimeout=90000;conn.instanceFollowRedirects=true;conn.setRequestProperty("User-Agent","AI-Music-Studio/1.0")
        if(offset>0)conn.setRequestProperty("Range","bytes=$offset-")
        try {
            val code=conn.responseCode
            val append=offset>0&&code==206
            if(code !in 200..299)throw IOException("HTTP $code al descargar ${item.title}")
            if(offset>0&&!append){ part.delete();offset=0 }
            val total=item.bytes
            val md=MessageDigest.getInstance("SHA-256")
            if(append)FileInputStream(part).use{input->val b=ByteArray(128*1024);var n:Int;while(input.read(b).also{n=it}>0)md.update(b,0,n)}
            var count=offset
            conn.inputStream.buffered(128*1024).use{input->FileOutputStream(part,append).buffered(128*1024).use{output->val b=ByteArray(128*1024);var n:Int;while(input.read(b).also{n=it}!=-1){output.write(b,0,n);md.update(b,0,n);count+=n;val now=count;main.post{l.progress(index,item.title,now,total)}}}}
            if(part.length()!=item.bytes)throw IOException("${item.title}: tamaño recibido ${part.length()} de ${item.bytes} bytes. Puedes reintentar; se conservará el avance parcial.")
            val hash=md.digest().joinToString(""){String.format(Locale.US,"%02x",it)}
            if(hash!=item.sha){part.delete();throw IOException("No coincide SHA-256 para ${item.title}; se eliminó el archivo incorrecto.")}
            if(dest.exists())dest.delete();if(!part.renameTo(dest))throw IOException("No se pudo guardar ${item.title}")
        } finally { conn.disconnect() }
    }
    private fun digest(f:File):String { val md=MessageDigest.getInstance("SHA-256");FileInputStream(f).use{val b=ByteArray(128*1024);var n:Int;while(it.read(b).also{n=it}!=-1)md.update(b,0,n)};return md.digest().joinToString(""){String.format(Locale.US,"%02x",it)} }
}
