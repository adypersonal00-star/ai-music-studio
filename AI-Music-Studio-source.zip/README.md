# AI Music Studio

Standalone Android app in Spanish for local SoundGen Quick audio generation. First launch downloads the four required model assets from their publishers and checks exact file sizes and SHA-256 digests. Partial files are resumed where the server supports HTTP Range. The home screen provides two tabs: sound effects (two text descriptions combined into one generation prompt) and music (description plus optional lyrics prompt). Both currently create one short WAV clip (1–11 seconds) using SoundGen Quick, with selectable diffusion steps (4/6/8), local playback, a recent creations list, and a full library with export through Android's document picker.

**Limitations / honesty:** the available SoundGen Quick implementation outputs WAV only; MP3/AAC export is not implemented. Lyrics are passed as prompt text but this model does not guarantee sung vocals or adherence to lyrics. The two effect descriptions form one combined prompt and are not promised as separate files. SoundGen Quick inference has not yet been verified on the target Infinix device. The initial model download is approximately 1.1 GB; generation can be memory-intensive and may fail on devices with limited RAM.

The adapted SoundGen Quick source is covered by PolyForm Noncommercial License 1.0.0 (see `THIRD_PARTY_NOTICES.md`). The model assets have separate publisher terms; review them before distribution. No model weights are bundled.

Build: JDK 17, Gradle 8.9, Android SDK 35: `gradle assembleDebug --no-daemon`.
